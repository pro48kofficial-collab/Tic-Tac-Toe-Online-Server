# Хрестики Нулики Online

Render:
- Build: `npm install`
- Start: `npm start`
- Environment: `DATABASE_URL` = Internal Database URL від PostgreSQL у Render.

PostgreSQL зберігає нік, аватар і перемоги. Тому сон/перезапуск Render не скидає прогрес.
